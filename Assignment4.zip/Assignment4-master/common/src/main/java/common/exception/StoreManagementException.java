package common.exception;

public class StoreManagementException extends Exception {

	private static final long serialVersionUID = 1L;

	public StoreManagementException(String msg) {
		super(msg);
	}
}
