package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreLocatorServiceApplicationTests {

	@Test
	void contextLoads() {
		assertFalse(false);
	}

}
